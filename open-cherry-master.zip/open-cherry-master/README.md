# Open Cherry
An open-source font based on Cherry legends. Made for the keycap designer community.


![](cover_image.png)
![](specimen.png)
